# MonCaisse MVP — V0.2

Application Flutter de cahier de caisse numérique, pensée pour une utilisation simple et hors connexion.

## Fonctionnalités présentes dans ce code
- Accueil avec solde théorique calculé à partir du solde de départ et des opérations actives.
- Enregistrement des entrées et sorties en FCFA.
- Catégories simples et date de l'opération distincte de la date de création.
- Historique des opérations.
- Annulation traçable (l'opération reste visible, mais n'entre plus dans les totaux).
- Paramétrage du nom et du type d'activité.
- Saisie du solde de départ, verrouillée dès qu'une opération existe pour éviter une modification silencieuse du calcul.
- Stockage local SQLite.

## Limites connues
- Gestion des dettes, transferts, clôture de caisse et comparaison entre périodes non encore implémentés.
- Sauvegarde/export/restauration pas encore implémentés.
- Code PIN et biométrie non implémentés.
- Ce projet est un prototype de développement et n'a pas encore été testé sur un vrai téléphone Android.

## Construire l'APK sans ordinateur (depuis un téléphone)
Le dépôt inclut un workflow GitHub Actions qui peut générer un APK dans le cloud.

1. Sur le téléphone, ouvre GitHub dans ton navigateur et crée un compte si nécessaire.
2. Crée un nouveau dépôt, par exemple `moncaisse-mvp`.
3. Téléverse le contenu de cette archive dans le dépôt en conservant les dossiers, notamment `.github/workflows/build-apk.yml`. Si l'interface mobile ne permet pas de téléverser un dossier complet, décompresse l'archive dans une application de fichiers puis téléverse les fichiers via le site GitHub, ou utilise GitHub Desktop depuis un ordinateur ultérieurement.
4. Ouvre l'onglet **Actions** du dépôt, sélectionne **Build MonCaisse APK**, puis **Run workflow** si nécessaire.
5. Attends que le workflow termine. Il doit réussir les étapes d'analyse, de tests et de compilation.
6. Dans le résultat de l'exécution, ouvre **Artifacts** et télécharge `moncaisse-debug-apk`. Décompresse l'archive téléchargée pour obtenir `app-debug.apk`.
7. Ouvre l'APK sur ton Android et autorise l'installation depuis cette source si Android le demande.

Si l'étape d'analyse ou de test échoue, aucun APK ne sera publié par ce workflow. Il faudra corriger les erreurs avant de continuer.

## Compilation locale
Avec Flutter et le SDK Android installés :

```bash
flutter create --platforms=android --org com.moncaisse .
flutter pub get
flutter analyze
flutter test
flutter build apk --debug
```

L'APK de débogage est destiné aux essais. Avant une utilisation réelle, il faut tester les calculs, la persistance après fermeture, les migrations, les annulations et les sauvegardes. Un APK de production nécessite une signature de publication.
