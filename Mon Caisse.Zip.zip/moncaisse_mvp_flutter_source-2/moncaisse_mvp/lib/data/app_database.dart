import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import '../models/cash_transaction.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();
  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    final root = await getDatabasesPath();
    _database = await openDatabase(
      p.join(root, 'moncaisse.db'),
      version: 2,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL CHECK(type IN ('ENTRY','EXIT')),
            amount INTEGER NOT NULL CHECK(amount > 0),
            category TEXT NOT NULL,
            note TEXT NOT NULL DEFAULT '',
            operation_date TEXT NOT NULL,
            created_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE','CANCELLED'))
          )
        ''');
        await db.execute('CREATE INDEX idx_transactions_date ON transactions(operation_date)');
        await db.execute('''CREATE TABLE app_settings (
          id INTEGER PRIMARY KEY CHECK(id = 1),
          activity_name TEXT NOT NULL DEFAULT 'Mon activité',
          activity_type TEXT NOT NULL DEFAULT 'Commerce',
          opening_balance INTEGER NOT NULL DEFAULT 0 CHECK(opening_balance >= 0)
        )''');
        await db.insert('app_settings', {'id': 1, 'activity_name': 'Ma boutique', 'activity_type': 'Commerce', 'opening_balance': 0});
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('''CREATE TABLE app_settings (
            id INTEGER PRIMARY KEY CHECK(id = 1),
            activity_name TEXT NOT NULL DEFAULT 'Mon activité',
            activity_type TEXT NOT NULL DEFAULT 'Commerce',
            opening_balance INTEGER NOT NULL DEFAULT 0 CHECK(opening_balance >= 0)
          )''');
          await db.insert('app_settings', {'id': 1, 'activity_name': 'Ma boutique', 'activity_type': 'Commerce', 'opening_balance': 0});
        }
      },
    );
    return _database!;
  }

  Future<int> insert(CashTransaction transaction) async {
    final db = await database;
    return db.insert('transactions', transaction.toMap()..remove('id'));
  }

  Future<List<CashTransaction>> getTransactions() async {
    final db = await database;
    final rows = await db.query('transactions', orderBy: 'operation_date DESC, id DESC');
    return rows.map(CashTransaction.fromMap).toList();
  }

  Future<int> cancel(int id) async {
    final db = await database;
    return db.update('transactions', {'status': 'CANCELLED'}, where: 'id = ?', whereArgs: [id]);
  }

  Future<Map<String, Object>> getSettings() async {
    final db = await database;
    final rows = await db.query('app_settings', where: 'id = 1', limit: 1);
    if (rows.isEmpty) {
      await db.insert('app_settings', {'id': 1, 'activity_name': 'Ma boutique', 'activity_type': 'Commerce', 'opening_balance': 0});
      return {'activity_name': 'Ma boutique', 'activity_type': 'Commerce', 'opening_balance': 0};
    }
    return rows.first;
  }

  Future<bool> hasAnyTransactions() async {
    final db = await database;
    final result = Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM transactions')) ?? 0;
    return result > 0;
  }

  Future<void> saveSettings({required String activityName, required String activityType, required int openingBalance}) async {
    final db = await database;
    await db.update('app_settings', {
      'activity_name': activityName.trim().isEmpty ? 'Mon activité' : activityName.trim(),
      'activity_type': activityType,
      'opening_balance': openingBalance,
    }, where: 'id = 1');
  }

  Future<Map<String, int>> totals() async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT type, COALESCE(SUM(amount), 0) AS total
      FROM transactions WHERE status = 'ACTIVE' GROUP BY type
    ''');
    var entries = 0;
    var exits = 0;
    for (final row in rows) {
      if (row['type'] == 'ENTRY') entries = (row['total'] as num).toInt();
      if (row['type'] == 'EXIT') exits = (row['total'] as num).toInt();
    }
    final settings = await getSettings();
    final opening = (settings['opening_balance'] as num?)?.toInt() ?? 0;
    return {'opening': opening, 'entries': entries, 'exits': exits, 'balance': opening + entries - exits};
  }
}
