import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/app_database.dart';
import '../models/cash_transaction.dart';
import '../theme/app_theme.dart';

class TransactionFormScreen extends StatefulWidget {
  const TransactionFormScreen({super.key, required this.isEntry});
  final bool isEntry;

  @override
  State<TransactionFormScreen> createState() => _TransactionFormScreenState();
}

class _TransactionFormScreenState extends State<TransactionFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _note = TextEditingController();
  String _category = 'Vente';
  bool _saving = false;
  DateTime _operationDate = DateTime.now();

  List<String> get _categories => widget.isEntry
      ? ['Vente', 'Paiement client', 'Cotisation', 'Don / financement', 'Autre']
      : ['Marchandise', 'Transport', 'Loyer', 'Électricité', 'Téléphone', 'Salaire', 'Carburant', 'Autre'];

  @override
  void initState() {
    super.initState();
    _category = _categories.first;
  }

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    try {
      await AppDatabase.instance.insert(CashTransaction(
        id: null,
        type: widget.isEntry ? 'ENTRY' : 'EXIT',
        amount: int.parse(_amount.text.replaceAll(' ', '')),
        category: _category,
        note: _note.text.trim(),
        operationDate: _operationDate,
        createdAt: DateTime.now(),
        status: 'ACTIVE',
      ));
      if (mounted) Navigator.pop(context, true);
    } catch (_) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Enregistrement impossible. Réessayez.')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _chooseDate() async {
    final now = DateTime.now();
    final chosen = await showDatePicker(
      context: context,
      initialDate: _operationDate,
      firstDate: DateTime(now.year - 10),
      lastDate: DateTime(now.year, now.month, now.day),
      helpText: 'Date de l’opération',
      cancelText: 'Annuler',
      confirmText: 'Choisir',
    );
    if (chosen != null && mounted) {
      setState(() => _operationDate = DateTime(chosen.year, chosen.month, chosen.day));
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEntry = widget.isEntry;
    final color = isEntry ? AppTheme.green : AppTheme.red;
    return Scaffold(
      appBar: AppBar(title: Text(isEntry ? "J'ai reçu" : "J'ai dépensé")),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              Text('Montant en FCFA', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              TextFormField(
                controller: _amount,
                autofocus: true,
                keyboardType: TextInputType.number,
                style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                decoration: const InputDecoration(hintText: 'Ex. : 25000', suffixText: 'FCFA'),
                validator: (value) {
                  final amount = int.tryParse((value ?? '').replaceAll(' ', ''));
                  if (amount == null || amount <= 0) return 'Entrez un montant supérieur à zéro.';
                  return null;
                },
              ),
              const SizedBox(height: 22),
              Text('Date de l’opération', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  alignment: Alignment.centerLeft,
                  minimumSize: const Size.fromHeight(52),
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                ),
                onPressed: _saving ? null : _chooseDate,
                icon: const Icon(Icons.calendar_today_outlined),
                label: Text(DateFormat('dd/MM/yyyy').format(_operationDate)),
              ),
              const SizedBox(height: 22),
              Text('Catégorie', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                value: _category,
                items: _categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
                onChanged: (value) => setState(() => _category = value ?? _category),
              ),
              const SizedBox(height: 22),
              Text('Note (facultatif)', style: Theme.of(context).textTheme.titleMedium),
              const SizedBox(height: 8),
              TextFormField(controller: _note, maxLines: 3, decoration: const InputDecoration(hintText: 'Ex. : Vente de riz')),
              const SizedBox(height: 28),
              SizedBox(
                height: 56,
                child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: color),
                  onPressed: _saving ? null : _save,
                  child: Text(_saving ? 'Enregistrement…' : 'Enregistrer', style: const TextStyle(fontSize: 17)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
