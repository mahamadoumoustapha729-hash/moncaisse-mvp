import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../data/app_database.dart';
import '../models/cash_transaction.dart';
import '../theme/app_theme.dart';
import 'transaction_form_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Map<String, int> _totals = {'entries': 0, 'exits': 0, 'balance': 0};
  List<CashTransaction> _transactions = [];
  int _tab = 0;
  String _activityName = 'Ma boutique';
  final _money = NumberFormat('#,##0', 'fr_FR');

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    final totals = await AppDatabase.instance.totals();
    final transactions = await AppDatabase.instance.getTransactions();
    final settings = await AppDatabase.instance.getSettings();
    if (mounted) setState(() { _totals = totals; _transactions = transactions; _activityName = settings['activity_name'] as String? ?? 'Ma boutique'; });
  }

  String _fcfa(int value) => '${_money.format(value).replaceAll('\u202f', ' ')} FCFA';

  Future<void> _openForm(bool isEntry) async {
    final saved = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => TransactionFormScreen(isEntry: isEntry)));
    if (saved == true) await _refresh();
  }

  Future<void> _cancel(CashTransaction transaction) async {
    if (transaction.id == null) return;
    final confirmed = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Annuler cette opération ?'),
      content: const Text('Elle restera visible dans l’historique comme opération annulée.'),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Garder')),
        FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Annuler l’opération'))],
    ));
    if (confirmed == true) { await AppDatabase.instance.cancel(transaction.id!); await _refresh(); }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('MONCAISSE', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1)),
          Text('$_activityName', style: TextStyle(fontSize: 13, fontWeight: FontWeight.normal)),
        ]),
        actions: [IconButton(onPressed: _refresh, icon: const Icon(Icons.refresh), tooltip: 'Actualiser')],
      ),
      body: _tab == 1 ? _history() : _tab == 2 ? _compare() : _tab == 3 ? _more() : _home(),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (index) => setState(() => _tab = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), label: 'Historique'),
          NavigationDestination(icon: Icon(Icons.compare_arrows), label: 'Comparer'),
          NavigationDestination(icon: Icon(Icons.more_horiz), label: 'Plus'),
        ],
      ),
    );
  }

  Widget _home() => RefreshIndicator(
    onRefresh: _refresh,
    child: ListView(padding: const EdgeInsets.all(18), children: [
      Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('SOLDE THÉORIQUE DE MA CAISSE', style: TextStyle(color: AppTheme.secondaryText, fontWeight: FontWeight.w700, fontSize: 12)),
        const SizedBox(height: 8),
        FittedBox(alignment: Alignment.centerLeft, fit: BoxFit.scaleDown, child: Text(_fcfa(_totals['balance'] ?? 0), style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: AppTheme.green))),
        const SizedBox(height: 18),
        Row(children: [
          Expanded(child: _metric('Reçu au total', _totals['entries'] ?? 0, AppTheme.green, Icons.arrow_downward)),
          const SizedBox(width: 12),
          Expanded(child: _metric('Dépensé au total', _totals['exits'] ?? 0, AppTheme.red, Icons.arrow_upward)),
        ]),
        const SizedBox(height: 10),
        const Text('Calculé à partir des opérations enregistrées.', style: TextStyle(fontSize: 12, color: AppTheme.secondaryText)),
      ]))),
      const SizedBox(height: 22),
      const Text('QUE VOULEZ-VOUS FAIRE ?', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: _action('J’AI REÇU', Icons.add_circle_outline, AppTheme.green, () => _openForm(true))), const SizedBox(width: 12), Expanded(child: _action('J’AI DÉPENSÉ', Icons.remove_circle_outline, AppTheme.red, () => _openForm(false)))]),
      const SizedBox(height: 12),
      Row(children: [Expanded(child: _action('ON ME DOIT', Icons.person_outline, const Color(0xFF1765B8), () => _comingSoon('Gestion des dettes'))), const SizedBox(width: 12), Expanded(child: _action('TRANSFERT', Icons.swap_horiz, const Color(0xFF6D3FB3), () => _comingSoon('Transferts entre comptes')))]),
      const SizedBox(height: 24),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [const Text('Dernières opérations', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)), TextButton(onPressed: () => setState(() => _tab = 1), child: const Text('Tout voir'))]),
      if (_transactions.isEmpty) _empty() else ..._transactions.take(5).map(_transactionTile),
    ]),
  );

  Widget _metric(String label, int amount, Color color, IconData icon) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: color.withValues(alpha: .08), borderRadius: BorderRadius.circular(14)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: color), const SizedBox(height: 8), Text(label, style: const TextStyle(fontSize: 12)), const SizedBox(height: 4), Text(_fcfa(amount), style: TextStyle(fontWeight: FontWeight.w800, color: color, fontSize: 15))]));

  Widget _action(String label, IconData icon, Color color, VoidCallback onTap) => SizedBox(height: 108, child: Material(color: color, borderRadius: BorderRadius.circular(18), child: InkWell(borderRadius: BorderRadius.circular(18), onTap: onTap, child: Padding(padding: const EdgeInsets.all(12), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: Colors.white, size: 30), const SizedBox(height: 8), Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 13))])))));

  Widget _history() => ListView(padding: const EdgeInsets.all(18), children: [const Text('Historique des opérations', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)), const SizedBox(height: 16), if (_transactions.isEmpty) _empty() else ..._transactions.map(_transactionTile)]);

  Widget _transactionTile(CashTransaction transaction) {
    final entry = transaction.type == 'ENTRY';
    final cancelled = transaction.status == 'CANCELLED';
    return Card(margin: const EdgeInsets.only(bottom: 10), child: ListTile(
      leading: CircleAvatar(backgroundColor: (cancelled ? Colors.grey : entry ? AppTheme.green : AppTheme.red).withValues(alpha: .12), child: Icon(entry ? Icons.south_west : Icons.north_east, color: cancelled ? Colors.grey : entry ? AppTheme.green : AppTheme.red)),
      title: Text(transaction.category, style: TextStyle(fontWeight: FontWeight.w700, decoration: cancelled ? TextDecoration.lineThrough : null)),
      subtitle: Text('${DateFormat('dd/MM/yyyy').format(transaction.operationDate)}${transaction.note.isEmpty ? '' : ' • ${transaction.note}'}${cancelled ? ' • ANNULÉE' : ''}'),
      trailing: Text('${entry ? '+' : '−'} ${_fcfa(transaction.amount)}', style: TextStyle(fontWeight: FontWeight.w800, color: cancelled ? Colors.grey : entry ? AppTheme.green : AppTheme.red, fontSize: 12)),
      onLongPress: cancelled ? null : () => _cancel(transaction),
    ));
  }

  Widget _empty() => Card(child: Padding(padding: const EdgeInsets.all(24), child: Column(children: [const Icon(Icons.menu_book_outlined, size: 42, color: AppTheme.green), const SizedBox(height: 12), const Text('Aucune opération pour le moment', style: TextStyle(fontWeight: FontWeight.w700)), const SizedBox(height: 6), const Text('Enregistrez votre première entrée ou dépense.', textAlign: TextAlign.center), const SizedBox(height: 12), FilledButton(onPressed: () => _openForm(true), child: const Text('Enregistrer une entrée'))])));

  Widget _more() => ListView(padding: const EdgeInsets.all(18), children: [const Text('Plus', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)), const SizedBox(height: 12), Card(child: ListTile(leading: const Icon(Icons.storefront_outlined), title: const Text('Mon activité'), subtitle: const Text('Nom, type et solde de départ'), trailing: const Icon(Icons.chevron_right), onTap: () async { final changed = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => const SettingsScreen())); if (changed == true) { await _refresh(); } })), const Card(child: ListTile(leading: Icon(Icons.shield_outlined), title: Text('Données locales'), subtitle: Text('Les opérations sont conservées sur ce téléphone.'))), const Card(child: ListTile(leading: Icon(Icons.backup_outlined), title: Text('Sauvegarde'), subtitle: Text('Fonctionnalité à intégrer avant une diffusion publique.')))]);

  Widget _compare() => ListView(padding: const EdgeInsets.all(20), children: [const Text('Résumé financier', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)), const SizedBox(height: 8), const Text('Depuis le début de l’utilisation'), const SizedBox(height: 18), _summaryRow('Argent reçu', _totals['entries'] ?? 0, AppTheme.green), _summaryRow('Argent dépensé', _totals['exits'] ?? 0, AppTheme.red), const Divider(height: 28), _summaryRow('Différence', _totals['balance'] ?? 0, AppTheme.text), const SizedBox(height: 14), const Text('La différence n’est pas nécessairement votre bénéfice : les achats de stock, les dettes et les autres mouvements peuvent changer son interprétation.', style: TextStyle(color: AppTheme.secondaryText, height: 1.4))]);

  Widget _summaryRow(String label, int amount, Color color) => Padding(padding: const EdgeInsets.symmetric(vertical: 12), child: Row(children: [Expanded(child: Text(label, style: const TextStyle(fontSize: 16))), Text(_fcfa(amount), style: TextStyle(fontWeight: FontWeight.w800, color: color, fontSize: 16))]));

  void _comingSoon(String feature) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$feature : prévu dans la prochaine étape.')));
}
