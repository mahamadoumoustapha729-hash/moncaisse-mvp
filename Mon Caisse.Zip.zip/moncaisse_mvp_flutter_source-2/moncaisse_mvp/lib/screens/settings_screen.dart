import 'package:flutter/material.dart';
import '../data/app_database.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _name = TextEditingController();
  final _opening = TextEditingController();
  String _type = 'Commerce';
  bool _loading = true;
  bool _hasTransactions = false;
  bool _saving = false;
  static const _types = ['Commerce', 'Service', 'Association / groupement', 'Entreprise', 'Autre'];

  @override
  void initState() { super.initState(); _load(); }
  @override
  void dispose() { _name.dispose(); _opening.dispose(); super.dispose(); }

  Future<void> _load() async {
    final settings = await AppDatabase.instance.getSettings();
    final hasTransactions = await AppDatabase.instance.hasAnyTransactions();
    if (!mounted) return;
    setState(() {
      _name.text = settings['activity_name'] as String? ?? 'Ma boutique';
      _type = settings['activity_type'] as String? ?? 'Commerce';
      _opening.text = ((settings['opening_balance'] as num?)?.toInt() ?? 0).toString();
      _hasTransactions = hasTransactions;
      _loading = false;
    });
  }

  Future<void> _save() async {
    final opening = int.tryParse(_opening.text.trim().replaceAll(' ', ''));
    if (_name.text.trim().isEmpty || opening == null || opening < 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vérifiez le nom et le solde de départ.')));
      return;
    }
    setState(() => _saving = true);
    try {
      await AppDatabase.instance.saveSettings(activityName: _name.text, activityType: _type, openingBalance: opening);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Paramètres enregistrés.')));
        Navigator.pop(context, true);
      }
    } catch (_) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Impossible d’enregistrer les paramètres.')));
    } finally { if (mounted) setState(() => _saving = false); }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Mon activité')),
    body: _loading ? const Center(child: CircularProgressIndicator()) : ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Personnalisez votre cahier de caisse.', style: TextStyle(fontSize: 16)),
      const SizedBox(height: 20),
      Text('Nom de l’activité', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      TextField(controller: _name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(hintText: 'Ex. : Boutique Amina')),
      const SizedBox(height: 20),
      Text('Type d’activité', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(value: _type, items: _types.map((t) => DropdownMenuItem(value: t, child: Text(t))).toList(), onChanged: (v) { if (v != null) setState(() => _type = v); }),
      const SizedBox(height: 20),
      Text('Argent déjà présent dans la caisse (FCFA)', style: Theme.of(context).textTheme.titleMedium),
      const SizedBox(height: 8),
      TextField(controller: _opening, enabled: !_hasTransactions, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'Ex. : 25000', suffixText: 'FCFA')),
      if (_hasTransactions) const Padding(padding: EdgeInsets.only(top: 8), child: Text('Le solde de départ est verrouillé après la première opération pour protéger vos calculs.', style: TextStyle(fontSize: 13, color: Colors.orange))),
      const SizedBox(height: 28),
      SizedBox(height: 54, child: FilledButton(onPressed: _saving ? null : _save, child: Text(_saving ? 'Enregistrement…' : 'Enregistrer'))),
      const SizedBox(height: 16),
      const ListTile(leading: Icon(Icons.wifi_off), title: Text('Fonctionne hors connexion'), subtitle: Text('Vos opérations sont enregistrées sur ce téléphone.')),
      const ListTile(leading: Icon(Icons.backup_outlined), title: Text('Sauvegarde'), subtitle: Text('La sauvegarde et la restauration seront ajoutées dans une prochaine étape.')),
    ]),
  );
}
