class CashTransaction {
  const CashTransaction({
    required this.id,
    required this.type,
    required this.amount,
    required this.category,
    required this.note,
    required this.operationDate,
    required this.createdAt,
    required this.status,
  });

  final int? id;
  final String type; // ENTRY or EXIT
  final int amount; // FCFA, integer only
  final String category;
  final String note;
  final DateTime operationDate;
  final DateTime createdAt;
  final String status; // ACTIVE or CANCELLED

  Map<String, Object?> toMap() => {
        'id': id,
        'type': type,
        'amount': amount,
        'category': category,
        'note': note,
        'operation_date': operationDate.toIso8601String(),
        'created_at': createdAt.toIso8601String(),
        'status': status,
      };

  factory CashTransaction.fromMap(Map<String, Object?> map) => CashTransaction(
        id: map['id'] as int?,
        type: map['type'] as String,
        amount: map['amount'] as int,
        category: map['category'] as String,
        note: map['note'] as String,
        operationDate: DateTime.parse(map['operation_date'] as String),
        createdAt: DateTime.parse(map['created_at'] as String),
        status: map['status'] as String,
      );
}
