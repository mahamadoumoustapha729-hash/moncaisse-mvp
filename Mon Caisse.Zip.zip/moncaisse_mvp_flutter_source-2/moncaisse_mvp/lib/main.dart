import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MonCaisseApp());
}

class MonCaisseApp extends StatelessWidget {
  const MonCaisseApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'MonCaisse',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        home: const HomeScreen(),
      );
}
